---
name: False positive
about: Report a false positive rule match
title: "[RULE NAME]"
labels: false positive

---

<!--

Have you read capa's Code of Conduct? By filing an Issue, you are expected to comply with it, including treating everyone with respect: https://github.com/mandiant/capa/blob/master/CODE_OF_CONDUCT.md
-->

## Summary

<!-- Rule name and one paragraph explanation of the false positive. -->

## Examples

<!-- If you can, please include a hash for the false positive rule match. If you've reverse engineered the sample please also include offsets or any additional information. -->

## Possible improvements

<!-- How can the rule be improved? -->

## Additional context

<!-- Add any other context or screenshots about the false positive here. -->
